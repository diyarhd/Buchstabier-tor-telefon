require("dotenv").config();
const express = require("express");
const twilio = require("twilio");

const app = express();
app.use(express.json({ limit: "100kb" }));
app.use(express.static("public"));

const { TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM_NUMBER } = process.env;
const PORT = Number(process.env.PORT || 3000);

function escapeXml(value) {
  return String(value).replace(/[<>&'"]/g, ch => ({
    "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;"
  }[ch]));
}

function spellWord(word) {
  return Array.from(word).map((ch, index) => {
    if (/^[A-ZÄÖÜ]$/.test(ch)) return `${index === 0 ? "Großes" : "großes"} ${ch}`;
    if (/^[a-zäöüß]$/.test(ch)) return `${index === 0 ? "Kleines" : "kleines"} ${ch}`;
    if (/^[0-9]$/.test(ch)) return `Ziffer ${ch}`;
    return ch;
  }).join(", ");
}

function buildTwiML(text, pauseSeconds, limitMinutes) {
  const words = text.trim().split(/\s+/).filter(Boolean);
  const xml = ['<?xml version="1.0" encoding="UTF-8"?>', '<Response>'];
  xml.push(`<Say language="de-DE">Guten Tag. Dies ist eine automatische Buchstabieransage. Sie können jederzeit auflegen. Die Ansage beginnt jetzt.</Say>`);
  // Keep the call within the selected limit by refusing texts that would plainly exceed it.
  for (let i = 0; i < words.length; i++) {
    const word = words[i].replace(/[.,!?;:]+$/g, "");
    xml.push(`<Say language="de-DE">${escapeXml(word)}.</Say>`);
    xml.push(`<Say language="de-DE">${escapeXml(spellWord(word))}.</Say>`);
    if (i < words.length - 1) xml.push(`<Pause length="${pauseSeconds}"/>`);
  }
  xml.push('<Say language="de-DE">Das war der gesamte Text. Auf Wiederhören.</Say>');
  xml.push('</Response>');
  return xml.join("");
}

app.get("/health", (_req, res) => res.json({ ok: true, service: "Twilio Buchstabier-Anruf" }));

app.post("/api/call", async (req, res) => {
  try {
    if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN || !TWILIO_FROM_NUMBER) {
      return res.status(503).json({ error: "Server noch nicht konfiguriert. Die Twilio-Zugangsdaten müssen sicher in .env hinterlegt werden." });
    }
    const { phone, text, pauseSeconds = 25, limitMinutes = 40, consent } = req.body || {};
    if (consent !== true) return res.status(400).json({ error: "Bitte bestätige, dass die angerufene Person dem Anruf zugestimmt hat." });
    if (typeof phone !== "string" || !/^\+[1-9]\d{7,14}$/.test(phone.trim())) {
      return res.status(400).json({ error: "Bitte die Telefonnummer im internationalen Format eingeben, zum Beispiel +43…." });
    }
    if (typeof text !== "string" || !text.trim()) return res.status(400).json({ error: "Bitte zuerst einen Text eingeben." });
    const words = text.trim().split(/\s+/).filter(Boolean);
    if (words.length > 120) return res.status(400).json({ error: "Maximal 120 Wörter pro Anruf in dieser Starter-Version." });
    const pause = Number(pauseSeconds);
    const limit = Number(limitMinutes);
    if (![5, 10, 15, 20, 25].includes(pause)) return res.status(400).json({ error: "Ungültige Pausenlänge." });
    if (![20, 30, 40].includes(limit)) return res.status(400).json({ error: "Ungültiges Zeitlimit." });
    // Conservative estimate: 25 seconds between words plus a little time per spoken word/letter.
    const estimatedSeconds = (words.length - 1) * pause + words.reduce((sum, w) => sum + Math.max(3, [...w].length * 0.55 + 2), 0) + 15;
    if (estimatedSeconds > limit * 60) {
      return res.status(400).json({ error: `Der Text dauert voraussichtlich länger als ${limit} Minuten. Kürze den Text oder erhöhe das Zeitlimit.` });
    }
    const client = twilio(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);
    const twiml = buildTwiML(text, pause, limit);
    const call = await client.calls.create({
      to: phone.trim(),
      from: TWILIO_FROM_NUMBER,
      twiml,
      timeLimit: limit * 60
    });
    res.json({ ok: true, callSid: call.sid, status: call.status, message: "Anruf wurde an Twilio übergeben. Der tatsächliche Verbindungsstatus kann sich noch ändern." });
  } catch (err) {
    console.error("Twilio call error:", err.message);
    res.status(502).json({ error: "Twilio konnte den Anruf nicht starten. Prüfe Kontostatus, verifizierte Zielnummern und ausgehende Rufnummer in der Twilio Console." });
  }
});

app.listen(PORT, () => console.log(`Server läuft auf http://localhost:${PORT}`));
