TWILIO BUCHSTABIER-ANRUF – STARTER FÜR EINEN ANRUF
=================================================

Was enthalten ist
- Eine kleine Webseite mit einem Telefonnummernfeld und einem Textfeld.
- Deutsche Ansage: Wort vorlesen, anschließend Buchstaben mit Groß-/Kleinschreibung ansagen.
- Einstellbare Pause zwischen Wörtern (5–25 Sekunden).
- Gesprächszeitlimit (20/30/40 Minuten).
- Servercode, der Twilio-Zugangsdaten serverseitig hält.

WICHTIG
- Dieses Paket ist ein Starter und noch keine veröffentlichte Webseite.
- Es wurde nicht mit deinem Twilio-Konto verbunden und hat noch keinen Anruf ausgeführt.
- Rufe nur Personen an, die dem automatisierten Anruf zugestimmt haben.
- Teile deinen Auth Token niemals im Chat und trage ihn nicht in die HTML-Datei ein.
- Twilio-Testkonten können ausgehende Anrufe einschränken; Zielnummern müssen je nach Kontostatus verifiziert sein.
- Für eine öffentlich erreichbare Webseite muss der Server über HTTPS erreichbar sein.
- Prüfe vor dem Einsatz die geltenden Regeln zu automatisierten Anrufen und Datenschutz.

Was für die echte Verbindung nötig ist
1. Einen Server/Hosting-Dienst mit Node.js auswählen.
2. Projektdateien dort bereitstellen.
3. Auf dem Server eine .env-Datei mit TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN und TWILIO_FROM_NUMBER anlegen.
4. In der Twilio Console prüfen, ob das Konto aktiv ist, ob die Zielnummer angerufen werden darf und welche ausgehende Rufnummer verwendet werden kann.
5. `npm install` und `npm start` ausführen.
6. HTTPS-Adresse öffnen und mit einer zustimmenden, eigenen Testnummer testen.

Lokaler Test (nur auf einem Computer mit Node.js)
1. Entpacke die ZIP-Datei.
2. Kopiere .env.example nach .env.
3. Fülle die echten Twilio-Werte nur lokal/serverseitig in .env aus.
4. Im Projektordner ausführen: npm install
5. Dann: npm start
6. Browser: http://localhost:3000

Hinweis zum iPad
Ein lokaler Server auf dem eigenen Computer ist nicht automatisch aus dem Internet erreichbar. Für die Nutzung von überall braucht es einen gehosteten Server. Die Zugangsdaten gehören ausschließlich dorthin, niemals in die Webseite.
